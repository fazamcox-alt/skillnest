from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import google.generativeai as genai

app = Flask(__name__)
CORS(app)

# আপনার জেমিনি এপিআই কি
genai.configure(api_key="AQ.Ab8RN6LSe3RKk0vU0bcToMUxr-zL-7PaoMTToFu0cVoUHXUFgw")

system_prompt = """
You are the world-class, highly intelligent, and elite AI career and business mentor for SkillNest. 
Core Philosophy: "Knowledge is not power, only applied knowledge is power."
Motto: "Unleash Your Potential" | "Learn, Grow, Lead"

CONVERSATION & MENTORING RULES (STRICTLY FOLLOW):
1. Always converse in extremely polite, standard Bengali using formal pronouns ("আপনি"). Treat every user with ultimate respect.
2. STAGE 1: Start with a warm Islamic greeting ("আসসালামু আলাইকুম। আশা করি আল্লাহর রহমতে ভালো আছেন।"). 
3. STAGE 2: Ask about their current status, profession, or educational background to understand who they are before giving advice.
4. STAGE 3: Tailor your tone and insights specifically to their domain (student, corporate official, or business holder) to trigger high-impact value.
"""

model = genai.GenerativeModel(
    model_name="gemini-3.6-flash",
    system_instruction=system_prompt
)

# প্রিমিয়াম ল্যান্ডিং পেজ + নিচের ডান কোণায় আধুনিক ফ্লোটিং চ্যাট উইজেট (Floating Chat Widget)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title>SkillNest - Unleash Your Potential</title>
    <style>
        body { font-family: 'SolaimanLipi', 'Segoe UI', Arial, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 0; display: flex; flex-direction: column; align-items: center; min-height: 100vh; }
        header { width: 100%; background: #1e293b; padding: 20px 40px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.3); box-sizing: border-box; }
        .logo { font-size: 24px; font-weight: bold; color: #10b981; }

        .hero { text-align: center; max-width: 850px; margin: 80px 20px 20px 20px; }
        .hero h1 { font-size: 48px; margin-bottom: 12px; color: #ffffff; font-weight: 700; letter-spacing: 0.5px; }
        .dots-motto { font-size: 18px; color: #38bdf8; font-weight: 600; margin-bottom: 20px; letter-spacing: 1px; }
        .hero p { font-size: 18px; color: #94a3b8; margin-bottom: 20px; }

        .philosophy { 
            font-size: 18px; 
            color: #facc15; 
            font-style: italic; 
            font-weight: 600; 
            margin-top: 20px; 
            background: rgba(30, 41, 59, 0.8);
            display: inline-block;
            padding: 12px 24px;
            border-radius: 30px;
            border: 1px solid rgba(250, 204, 21, 0.3);
            box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }

        /* ফ্লোটিং চ্যাট উইজেট (Floating Chat Widget) */
        .chat-btn { position: fixed; bottom: 25px; right: 25px; background: #10b981; color: white; border: none; border-radius: 50px; padding: 15px 25px; font-size: 16px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 20px rgba(0,0,0,0.5); z-index: 1000; transition: 0.3s; }
        .chat-btn:hover { background: #059669; transform: scale(1.05); }

        .chat-popup { position: fixed; bottom: 90px; right: 25px; width: 380px; height: 500px; background: #1e293b; border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.6); display: none; flex-direction: column; z-index: 1000; overflow: hidden; border: 1px solid #334155; }
        .chat-header { background: #0f172a; padding: 15px; color: #38bdf8; font-weight: bold; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; }
        .close-btn { background: none; border: none; color: #94a3b8; font-size: 18px; cursor: pointer; }
        .close-btn:hover { color: white; }

        .chat-box { flex: 1; overflow-y: auto; padding: 15px; display: flex; flex-direction: column; gap: 12px; }
        .message { padding: 10px 14px; border-radius: 8px; max-width: 85%; line-height: 1.4; font-size: 14px; }
        .user { background: #3b82f6; align-self: flex-end; color: white; }
        .bot { background: #334155; align-self: flex-start; color: #f1f5f9; }

        .input-group { display: flex; padding: 12px; background: #0f172a; border-top: 1px solid #334155; gap: 8px; }
        input { flex: 1; padding: 10px; border: none; border-radius: 6px; background: #1e293b; color: white; outline: none; font-size: 14px; }
        .send-btn { padding: 10px 16px; border: none; background: #10b981; color: white; border-radius: 6px; cursor: pointer; font-weight: bold; }
        .send-btn:hover { background: #059669; }
    </style>
</head>
<body>

    <header>
        <div class="logo">SkillNest</div>
        <div style="font-size: 14px; color: #94a3b8;">Elite AI Mentorship Platform</div>
    </header>

    <div class="hero">
        <h1>Unleash Your Potential</h1>
        <div class="dots-motto">Learn &bull; Grow &bull; Lead</div>
        <p>আপনার ক্যারিয়ার ও পেশাগত উৎকর্ষ সাধনে বিশ্বস্ত ডিজিটাল মেন্টর</p>
        <div>
            <div class="philosophy">💡 “Knowledge is not power, only applied knowledge is power.”</div>
        </div>
    </div>

    <!-- ফ্লোটিং চ্যাট বাটন -->
    <button class="chat-btn" onclick="toggleChat()">💬 AI মেন্টরের সাথে কথা বলুন</button>

    <!-- চ্যাট পপআপ উইন্ডো -->
    <div class="chat-popup" id="chatPopup">
        <div class="chat-header">
            <span>SkillNest Live AI Mentor</span>
            <button class="close-btn" onclick="toggleChat()">&times;</button>
        </div>
        <div class="chat-box" id="chatBox">
            <div class="message bot">আসসালামু আলাইকুম। আশা করি আল্লাহর রহমতে ভালো আছেন। আপনি এখন কী করছেন বা কোন পেশার সাথে যুক্ত আছেন, যদি একটু বলতেন?</div>
        </div>
        <div class="input-group">
            <input type="text" id="userInput" placeholder="আপনার কথা এখানে লিখুন..." onkeypress="handleKey(event)">
            <button class="send-btn" onclick="sendMessage()">পাঠান</button>
        </div>
    </div>

    <script>
        function toggleChat() {
            const popup = document.getElementById('chatPopup');
            popup.style.display = popup.style.display === 'flex' ? 'none' : 'flex';
        }

        async function sendMessage() {
            const input = document.getElementById('userInput');
            const chatBox = document.getElementById('chatBox');
            const text = input.value.trim();
            if(!text) return;

            chatBox.innerHTML += `<div class="message user">${text}</div>`;
            input.value = '';
            chatBox.scrollTop = chatBox.scrollHeight;

            try {
                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({message: text})
                });
                const data = await response.json();
                chatBox.innerHTML += `<div class="message bot">${data.reply}</div>`;
            } catch (err) {
                chatBox.innerHTML += `<div class="message bot">দুঃখিত, সংযোগে সমস্যা হয়েছে।</div>`;
            }
            chatBox.scrollTop = chatBox.scrollHeight;
        }
        function handleKey(e) { if(e.key === 'Enter') sendMessage(); }
    </script>
</body>
</html>
"""


@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)


@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '')
    if not user_message:
        return jsonify({'error': 'Message is required'}), 400
    try:
        response = model.generate_content(user_message)
        return jsonify({'reply': response.text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    print("--- SkillNest Floating Chat Landing Page Running on port 5000 ---")
    app.run(port=5000, debug=True)