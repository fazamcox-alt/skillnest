# SkillNest - AI Career & Business Mentor

> **"Knowledge is not power, only applied knowledge is power."**  
> *Unleash Your Potential* | *Learn, Grow, Lead*

## 🚀 About the Project
SkillNest is an elite, AI-driven mentorship platform designed to provide real-time, personalized guidance for students, corporate professionals, and business leaders. Built with advanced generative AI, it adopts a psychological, conversational approach—diagnosing user needs through a structured discovery phase before tailoring high-impact solutions.

## ✨ Key Features
- **Intelligent Persona & Empathy Flow:** Follows a strict protocol starting with formal greetings, background analysis, and tailored domain-specific advice.
- **Modern Floating UI:** Sleek, distraction-free landing page with a responsive, pop-up chat widget.
- **Applied AI Integration:** Powered by Google Gemini API to deliver sharp, value-driven insights.

## 🛠️ Tech Stack
- **Backend:** Python, Flask, Flask-CORS
- **AI Engine:** Google Gemini Generative AI SDK
- **Frontend:** HTML5, CSS3, JavaScript (Responsive Dark Theme UI)

## ⚙️ How to Run Locally
1. Clone the repository:
   ```bash
   git clone [https://github.com/fazamcox-alt/skillnest.git](https://github.com/fazamcox-alt/skillnest.git)